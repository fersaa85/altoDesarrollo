<?php

namespace App\Repositories\Contact;

interface ContactRepositoryInterface
{
    public function create(array  $data);
}
